/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mambokings.nenemalo.controls;

import com.mambokings.nenemalo.views.Ventana;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author yayis
 */
public class Procesos {

    ArrayList<String> linesList = new ArrayList<>(); // ArrayList para almacenar las lineas del archivo
    Ventana v;

    public Procesos(Ventana v) {
        this.v = v;
    }

    public void openFile() {
        JFileChooser fileChooser = new JFileChooser(); // Crea un JFileChooser
        int result = fileChooser.showOpenDialog(null); // Despliega ventana de selccion

        if (result == JFileChooser.APPROVE_OPTION) { // Si se selecciona un archivo
            File selectedFile = fileChooser.getSelectedFile(); // Obtiene el archivo seleccionado
            readFile(selectedFile); // Llama al método para leer el archivo
        }
    }

    private void readFile(File file) {
        linesList.clear(); // Limpiar la lista antes de leer un nuevo archivo

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
                linesList.add(line); // Agregar cada línea al ArrayList
            }

            reader.close();

            // Imprimir las líneas almacenadas en el ArrayList
            for (String storedLine : linesList) {
                System.out.println(storedLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

